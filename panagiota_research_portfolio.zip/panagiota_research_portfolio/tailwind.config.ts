import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./app/**/*.{js,ts,jsx,tsx}', './components/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#070A12',
        panel: '#0D1222',
        cyanSoft: '#8BE9FD',
        violetSoft: '#C084FC'
      },
      boxShadow: {
        glow: '0 0 60px rgba(139, 233, 253, 0.12)'
      }
    }
  },
  plugins: []
};

export default config;
