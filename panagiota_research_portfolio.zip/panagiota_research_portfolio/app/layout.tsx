import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Panagiota Grosdouli | AI & Robotics Portfolio',
  description: 'Research portfolio in AI, robotics, autonomous systems, simulation, and scientific machine learning.'
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
