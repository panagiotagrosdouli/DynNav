'use client';

import { motion } from 'framer-motion';
import { ArrowUpRight, Bot, Brain, Cpu, Github, GraduationCap, LineChart, Radar, Rocket, ShieldCheck, Sparkles } from 'lucide-react';

const projects = [
  {
    title: 'DynNav',
    subtitle: 'Dynamic Navigation & Rerouting in Unknown Environments',
    description: 'Research dashboard and autonomous navigation framework combining uncertainty-aware planning, risk maps, safety reasoning, and robotics intelligence.',
    tags: ['Robotics', 'ROS2', 'Planning', 'Uncertainty', 'Safety'],
    live: 'https://dynnav-dynamic-navigation-rerouting-in-unknown-environments-fq.streamlit.app/',
    github: 'https://github.com/panagiotagrosdouli/DynNav-Dynamic-Navigation-Rerouting-in-Unknown-Environments',
    icon: Bot
  },
  {
    title: 'Formula1 Race Simulation',
    subtitle: 'Motorsport Intelligence Platform',
    description: 'Machine-learning-driven F1 analytics platform with telemetry, Monte Carlo simulation, strategy optimization, and deployed Streamlit dashboard.',
    tags: ['ML', 'Simulation', 'Telemetry', 'Streamlit', 'Strategy'],
    live: 'https://formula1-race-simulation-x8ajjwdsvf6igouiu4hwf3.streamlit.app/',
    github: 'https://github.com/panagiotagrosdouli/formula1-race-simulation',
    icon: LineChart
  },
  {
    title: 'CASim',
    subtitle: 'Parametric Cellular Automata Simulator',
    description: 'Research-oriented framework for multi-dimensional cellular automata simulation, emergent complexity analysis, entropy modeling, and dynamical systems exploration.',
    tags: ['Complex Systems', 'Simulation', 'Entropy', 'Scientific Computing'],
    live: '',
    github: 'https://github.com/panagiotagrosdouli/CASim-A-Parametric-Cellular-Automata-Simulator-',
    icon: Sparkles
  },
  {
    title: 'Wafer Fault Detection',
    subtitle: 'ML for Semiconductor Defect Classification',
    description: 'Research-driven wafer defect classification framework combining classical ML and CNN-based approaches under severe class imbalance.',
    tags: ['CNN', 'Semiconductors', 'Class Imbalance', 'ML'],
    live: '',
    github: 'https://github.com/panagiotagrosdouli/wafer-fault-detection-with-ml',
    icon: Cpu
  },
  {
    title: 'Memristor Modeling with ML',
    subtitle: 'AI for Memristive Device Modeling',
    description: 'Scientific ML project focused on modeling memristors and device behavior using machine learning and deep learning methods.',
    tags: ['Memristors', 'Deep Learning', 'Device Modeling', 'RRAM'],
    live: '',
    github: 'https://github.com/panagiotagrosdouli/Modeling-Memristors-with-Machine-Learning',
    icon: Brain
  },
  {
    title: 'UAV Risk-Aware Return-to-Home',
    subtitle: 'Battery Uncertainty & Wind Disturbances',
    description: 'Risk-aware UAV policy research project for safe return-to-home decisions under energy uncertainty and environmental disturbances.',
    tags: ['UAV', 'Risk-Aware AI', 'Optimization', 'Autonomy'],
    live: '',
    github: 'https://github.com/panagiotagrosdouli/Risk-Aware-Return-to-Home-Policy-for-UAVs-under-Battery-Uncertainty-and-Wind-Disturbances',
    icon: Radar
  }
];

const interests = [
  'Autonomous Systems',
  'Scientific Machine Learning',
  'Probabilistic Robotics',
  'Risk-Aware AI',
  'Complex Systems',
  'Simulation & Optimization',
  'Computer Vision',
  'AI for Engineering'
];

const skills = ['Python', 'Machine Learning', 'Deep Learning', 'Streamlit', 'ROS2', 'Simulation', 'Scientific Computing', 'Data Visualization', 'Control & Planning', 'Computer Vision'];

function SectionTitle({ eyebrow, title, text }: { eyebrow: string; title: string; text: string }) {
  return (
    <div className="mx-auto max-w-3xl text-center">
      <p className="mb-3 text-sm font-semibold uppercase tracking-[0.28em] text-cyanSoft">{eyebrow}</p>
      <h2 className="text-3xl font-bold text-white md:text-5xl">{title}</h2>
      <p className="mt-5 text-base leading-8 text-slate-300">{text}</p>
    </div>
  );
}

export default function Home() {
  return (
    <main className="min-h-screen overflow-hidden bg-ink text-slate-100">
      <nav className="fixed left-0 right-0 top-0 z-50 border-b border-white/10 bg-ink/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
          <a href="#home" className="text-sm font-bold tracking-widest text-white">PG</a>
          <div className="hidden gap-6 text-sm text-slate-300 md:flex">
            <a href="#projects" className="hover:text-cyanSoft">Projects</a>
            <a href="#research" className="hover:text-cyanSoft">Research</a>
            <a href="#skills" className="hover:text-cyanSoft">Skills</a>
            <a href="#contact" className="hover:text-cyanSoft">Contact</a>
          </div>
        </div>
      </nav>

      <section id="home" className="grid-bg relative flex min-h-screen items-center px-5 pt-24">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-ink/80 to-ink" />
        <div className="relative mx-auto grid max-w-7xl gap-12 py-24 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-cyanSoft/30 bg-cyanSoft/10 px-4 py-2 text-sm text-cyanSoft">
              <Rocket size={16} /> AI • Robotics • Scientific Computing
            </div>
            <h1 className="max-w-4xl text-5xl font-black leading-tight text-white md:text-7xl">
              Panagiota Grosdouli
            </h1>
            <p className="mt-6 max-w-2xl text-xl leading-9 text-slate-300">
              Electrical & Computer Engineering student building research-style systems in autonomous navigation, machine learning, simulation, robotics, and scientific computing.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <a href="#projects" className="rounded-2xl bg-cyanSoft px-6 py-3 font-semibold text-ink shadow-glow transition hover:scale-[1.02]">View Projects</a>
              <a href="https://github.com/panagiotagrosdouli" target="_blank" className="inline-flex items-center gap-2 rounded-2xl border border-white/15 px-6 py-3 font-semibold text-white hover:border-cyanSoft/60">
                <Github size={18} /> GitHub
              </a>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.8, delay: 0.1 }} className="rounded-[2rem] border border-white/10 bg-panel/80 p-6 shadow-glow backdrop-blur">
            <div className="rounded-[1.5rem] border border-white/10 bg-white/[0.03] p-6">
              <p className="text-sm uppercase tracking-[0.25em] text-slate-400">Research Identity</p>
              <div className="mt-6 space-y-4">
                {[
                  ['Autonomous Systems', 'Risk-aware navigation, replanning, safety layers'],
                  ['Scientific ML', 'Modeling physical and engineering systems'],
                  ['Simulation', 'Monte Carlo, dynamical systems, uncertainty'],
                  ['AI Engineering', 'Dashboards, reproducibility, deployed demos']
                ].map(([a, b]) => (
                  <div key={a} className="rounded-2xl border border-white/10 bg-ink/60 p-4">
                    <p className="font-semibold text-white">{a}</p>
                    <p className="mt-1 text-sm text-slate-400">{b}</p>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      <section id="projects" className="px-5 py-24">
        <SectionTitle eyebrow="Selected Work" title="Flagship Projects" text="A portfolio focused on research-grade systems, deployed dashboards, scientific modeling, and AI for engineering." />
        <div className="mx-auto mt-14 grid max-w-7xl gap-6 md:grid-cols-2 xl:grid-cols-3">
          {projects.map((project, idx) => {
            const Icon = project.icon;
            return (
              <motion.article key={project.title} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: idx * 0.06 }} className="group rounded-[1.75rem] border border-white/10 bg-panel/70 p-6 shadow-glow transition hover:-translate-y-1 hover:border-cyanSoft/40">
                <div className="mb-5 flex items-center justify-between">
                  <div className="rounded-2xl bg-cyanSoft/10 p-3 text-cyanSoft"><Icon size={24} /></div>
                  <div className="flex gap-2">
                    {project.github && <a href={project.github} target="_blank" className="rounded-full border border-white/10 p-2 text-slate-300 hover:text-cyanSoft"><Github size={16} /></a>}
                    {project.live && <a href={project.live} target="_blank" className="rounded-full border border-white/10 p-2 text-slate-300 hover:text-cyanSoft"><ArrowUpRight size={16} /></a>}
                  </div>
                </div>
                <h3 className="text-xl font-bold text-white">{project.title}</h3>
                <p className="mt-1 text-sm font-medium text-cyanSoft">{project.subtitle}</p>
                <p className="mt-4 min-h-[96px] text-sm leading-7 text-slate-300">{project.description}</p>
                <div className="mt-5 flex flex-wrap gap-2">
                  {project.tags.map(tag => <span key={tag} className="rounded-full bg-white/5 px-3 py-1 text-xs text-slate-300">{tag}</span>)}
                </div>
              </motion.article>
            );
          })}
        </div>
      </section>

      <section id="research" className="border-y border-white/10 bg-white/[0.03] px-5 py-24">
        <SectionTitle eyebrow="Research Direction" title="AI for Engineering Systems" text="My work is centered on building computational systems that model, simulate, optimize, and explain complex engineering behavior." />
        <div className="mx-auto mt-12 grid max-w-6xl gap-4 md:grid-cols-4">
          {interests.map(item => (
            <div key={item} className="rounded-2xl border border-white/10 bg-ink/60 p-5 text-center text-sm font-semibold text-slate-200">{item}</div>
          ))}
        </div>
      </section>

      <section id="skills" className="px-5 py-24">
        <SectionTitle eyebrow="Technical Stack" title="Skills & Tools" text="A practical stack for ML research, simulation, visualization, and deployed AI applications." />
        <div className="mx-auto mt-12 flex max-w-5xl flex-wrap justify-center gap-3">
          {skills.map(skill => <span key={skill} className="rounded-full border border-white/10 bg-panel px-5 py-3 text-sm text-slate-200">{skill}</span>)}
        </div>
      </section>

      <section id="contact" className="px-5 pb-24">
        <div className="mx-auto max-w-5xl rounded-[2rem] border border-white/10 bg-gradient-to-br from-cyanSoft/10 to-violetSoft/10 p-8 text-center shadow-glow md:p-12">
          <GraduationCap className="mx-auto mb-5 text-cyanSoft" size={34} />
          <h2 className="text-3xl font-bold text-white md:text-5xl">Open to research, internships, and collaboration</h2>
          <p className="mx-auto mt-5 max-w-2xl text-slate-300">Interested in autonomous systems, scientific ML, robotics, simulations, and AI for engineering.</p>
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            <a href="mailto:p.g2a15@gmail.com" className="rounded-2xl bg-white px-6 py-3 font-semibold text-ink">Email Me</a>
            <a href="https://github.com/panagiotagrosdouli" target="_blank" className="rounded-2xl border border-white/15 px-6 py-3 font-semibold text-white">GitHub Profile</a>
          </div>
        </div>
      </section>
    </main>
  );
}
