# Panagiota Grosdouli — AI & Robotics Portfolio

A modern personal research portfolio website built with Next.js, Tailwind CSS, and Framer Motion.

## Sections

- Hero introduction
- Featured projects
- Research interests
- Skills and tools
- Contact section

## Featured Projects

- DynNav — Dynamic Navigation & Rerouting in Unknown Environments
- Formula1 Race Simulation — Motorsport Intelligence Platform
- CASim — Cellular Automata Simulator
- Wafer Fault Detection with ML
- Modeling Memristors with Machine Learning
- UAV Risk-Aware Return-to-Home Policy

## Local Run

```bash
npm install
npm run dev
```

Open:

```text
http://localhost:3000
```

## Deploy on Vercel

1. Push this folder to GitHub.
2. Go to https://vercel.com
3. Import the GitHub repo.
4. Deploy.

## Customize

Edit project links, descriptions, and sections in:

```text
app/page.tsx
```
